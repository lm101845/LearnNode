console.log('b.js 被加载了')

module.exports = function () {
  console.log('hello bbb')
}
