console.log('a.js 被加载了')
var fn = require('./b')

console.log(fn)
