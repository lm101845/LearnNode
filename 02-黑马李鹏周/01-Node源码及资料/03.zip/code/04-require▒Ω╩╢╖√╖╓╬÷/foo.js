console.log('foo 文件模块被加载了')
