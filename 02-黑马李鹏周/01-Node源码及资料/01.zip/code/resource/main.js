window.alert('你好，Node.js')
