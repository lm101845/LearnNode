var foo = 'hello nodejs'

console.log(foo)
