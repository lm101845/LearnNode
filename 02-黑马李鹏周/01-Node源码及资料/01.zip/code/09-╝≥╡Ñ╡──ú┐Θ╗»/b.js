console.log('b start')

// console.log(add(10, 20))

var foo = 'bbb'

require('./c.js')
console.log('b end')
