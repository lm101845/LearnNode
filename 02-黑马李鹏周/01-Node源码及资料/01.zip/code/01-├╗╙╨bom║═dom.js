// 在 Node 中，采用 EcmaScript 进行编码
// 没有 BOM、DOM
// 和浏览器中的 JavaScript 不一样
console.log(window)
console.log(document)
